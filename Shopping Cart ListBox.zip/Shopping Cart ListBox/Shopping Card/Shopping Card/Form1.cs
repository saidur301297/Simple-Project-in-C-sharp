﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Shopping_Card
{
    public partial class shoppingCart : Form
    {
        int i = 0;
        Double price = 0;
        Double quantity = 0;
        string product = "";
        Double total = 0;
        Double totalprice = 0;
        Double sum = 0;
        String productShow = "{0,-10}{1, -30}{2,-30}{3,-30}{4,-30}";
        public shoppingCart()
        {
            InitializeComponent();
        }

        private void addButton_Click(object sender, EventArgs e)
        {

            i=i+1;
            product = addProductTextBox.Text;
            quantity =double.Parse( quantityTextBox.Text);
            price = double.Parse(priceTextBox.Text);
            total = price * quantity;
            sum = sum + total;
            totalprice = sum + sum * .05;
            
   
            productListBox.Items.Add(String.Format(productShow,i, product , quantity , price , total));

            
       
            addProductTextBox.Clear();
            priceTextBox.Clear();
            quantityTextBox.Clear();
           
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            
          
           
               
            
           

        }

        private void productListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void shoppingCart_Load(object sender, EventArgs e)
        {
            productListBox.Items.Add(String.Format(productShow,"SI NO", "Product", "Quantity", "Price", "Total Price"));

        }

        private void totalPayButton_Click(object sender, EventArgs e)
        {
            int d = (int)Math.Round(totalprice);
            totalBillTextBox.Text = System.Convert.ToString(totalprice);
        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            if (productListBox.SelectedIndex != -1)
            {
                productListBox.Items.RemoveAt(productListBox.SelectedIndex);
            }
        }

        private void updateButton_Click(object sender, EventArgs e)
        {
            int index = productListBox.SelectedIndex;
            productListBox.Items.RemoveAt(index);
            productListBox.Items.Insert(index,addProductTextBox.Text);
            productListBox.Items.Add(String.Format(productShow, i, product, quantity, price, total));
        }
    }
}
